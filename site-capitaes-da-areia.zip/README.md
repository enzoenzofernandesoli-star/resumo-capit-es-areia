# Resumo: Capitães da Areia (Jorge Amado)

Site de estudo para prova sobre *Capitães da Areia* (1937).

- **`index.html`**: resumo completo em 9 páginas: ficha rápida, contexto e escola literária, as cartas da abertura, a história capítulo por capítulo (com a análise de cada cena), personagens, temas e revisão final. Tem 33 ilustrações e 62 perguntas de prática clicáveis.
- **`mapa.html`**: mapa mental interativo. Toque numa cena para ver quem aparece; toque num personagem para ver o caminho dele no livro.
- **`resumo.md`**: o mesmo resumo em texto, com as perguntas e respostas.

## Como abrir

Abra `index.html` no navegador, ou ative o GitHub Pages (Settings → Pages → Deploy from a branch → `main` / root) para ter o site online.

Os números de página citados ("p.") são do PDF da edição Record usado no estudo.
