# CAPITÃES DA AREIA (Jorge Amado, 1937): resumo completo para a prova

> Como este resumo está organizado: **1–2** dão o básico e o contexto. **3–6** contam a história na ordem do livro, capítulo por capítulo, e cada cena importante já vem com a análise logo abaixo, sem repetir a cena em outro lugar. **7** traz os personagens, **8** os temas e **9** é a revisão final para a véspera da prova. No fim de cada página há um bloco **Pratique** com perguntas e respostas. As páginas citadas ("p.") são as do PDF que você mandou (edição Record); em outras edições os números mudam. ★ marca as cenas que mais caem.

---

## 1. Comece aqui: ficha rápida

| Item | Resposta |
|---|---|
| Autor | Jorge Amado (baiano, militante do Partido Comunista) |
| Publicação | 1937, escrito entre Estância (SE, março/1937) e o navio *Rakuyo Maru*, a caminho do México (junho/1937), segundo as datas no fim do livro |
| Movimento | **2ª geração modernista (Romance de 30)**: prosa **regionalista e social**, também chamada **neorrealista** |
| Espaço | Salvador (Bahia): trapiche abandonado no areal do cais, docas, ladeiras, Cidade Alta (ricos) × Cidade Baixa (pobres) |
| Tempo | Anos 1930, Era Vargas |
| Narrador | 3ª pessoa, onisciente, que toma partido dos meninos e fala muito pela cabeça deles (discurso indireto livre) |
| Estrutura | "Cartas à redação" + 3 partes: **1) Sob a lua, num velho trapiche abandonado; 2) Noite da grande paz, da grande paz dos teus olhos; 3) Canção da Bahia, canção da liberdade** |
| Protagonista | Pedro Bala, líder do grupo (15 anos no início) |
| Tema central | Menores abandonados, injustiça social, formação da consciência de classe |
| Fato histórico | Em 1937, com o **Estado Novo** de Getúlio Vargas, o livro foi apreendido e **exemplares foram queimados em praça pública em Salvador** junto com outros livros "subversivos" |
| Frase-síntese | **"Nem o ódio, nem a bondade. Só a luta."** (Pedro Bala) |

**O livro em 5 linhas:** uns cem meninos abandonados vivem de roubo num trapiche no cais de Salvador, liderados por Pedro Bala. A Parte 1 mostra a vida, as aventuras e as dores de cada um. Na Parte 2 chega Dora, órfã da varíola, que vira mãe, irmã, noiva e esposa do grupo, até ser presa, adoecer e morrer. Na Parte 3 o grupo se desfaz: cada menino segue um destino, e Pedro Bala descobre a luta coletiva e vira militante revolucionário.

### Pratique: página 1

1. Em que ano Capitães da Areia foi publicado e o que aconteceu com ele?
    - A) 1930, virou filme no mesmo ano
    - B) 1937, foi apreendido e queimado em Salvador
    - C) 1945, ganhou prêmio do governo Vargas
    - D) 1922, abriu a Semana de Arte Moderna
    - *Resposta: B. Saiu em 1937 e, com o Estado Novo, exemplares foram queimados em praça pública em Salvador.*
2. Quais são as três partes do livro, na ordem?
    - A) Trapiche; Noite da grande paz; Canção da Bahia
    - B) Canção da Bahia; Trapiche; Noite da grande paz
    - C) Cartas; Reformatório; Greve
    - D) Areal; Orfanato; Sertão
    - *Resposta: A. "Sob a lua, num velho trapiche abandonado", "Noite da grande paz, da grande paz dos teus olhos" e "Canção da Bahia, canção da liberdade".*
3. Que tipo de narrador o livro tem?
    - A) 1ª pessoa, Pedro Bala contando
    - B) 3ª pessoa onisciente, que toma partido dos meninos
    - C) Narrador-testemunha, o Professor
    - D) Vários narradores em 1ª pessoa
    - *Resposta: B. O narrador é em 3ª pessoa, sabe o que os meninos pensam e fica do lado deles.*
4. Resuma o livro em três frases (uma por parte).
    - *Resposta esperada: Parte 1: a vida e as aventuras dos meninos do trapiche e o despertar de Pedro Bala. Parte 2: Dora chega, vira mãe, irmã, noiva e esposa e morre. Parte 3: o grupo se desfaz em destinos individuais e Pedro Bala vira militante revolucionário.*
5. Qual é a frase-síntese da ideologia do livro e quem a diz?
    - *Resposta esperada: "Nem o ódio, nem a bondade. Só a luta." Dita por Pedro Bala a Sem-Pernas, ao verem Pirulito ensinando catecismo.*


---

## 2. Contexto e escola literária

### Getúlio Vargas, comunismo e o livro queimado
- **Era Vargas (1930–1945).** Depois da Intentona Comunista (1935), o governo endureceu: Lei de Segurança Nacional, perseguição a comunistas, censura. Em **novembro de 1937** começa o **Estado Novo**, a ditadura de Getúlio.
- Jorge Amado era comunista e foi preso. *Capitães da Areia* saiu no mesmo ano e foi **apreendido e queimado** pelo regime, acusado de propaganda comunista.
- **Dentro do livro**, a repressão aparece em:
  - na polícia que bate em crianças e invade candomblés (a "religião ilegal dos negros");
  - no Cônego que chama o padre José Pedro de "comunista" e fala em "inovações soviéticas";
  - no último capítulo, com os jornais clandestinos, os partidos ilegais e "o ano em que todas as bocas foram impedidas de falar", uma alusão à ditadura. Pedro Bala acaba preso "numa colônia" (penal) e foge.

### 2ª geração modernista, Romance de 30 e neorrealismo
- **2ª geração modernista (1930–45).** A prosa larga a experimentação da 1ª fase (1922) e passa a **denunciar os problemas sociais do Brasil**. Colegas de geração: Graciliano Ramos (*Vidas Secas*), Rachel de Queiroz (*O Quinze*), José Lins do Rego (*Menino de Engenho*), Érico Veríssimo.
- **Neorrealismo.** É uma volta ao realismo e ao naturalismo do século XIX, agora com olhar **político** (influência marxista). Suas marcas no livro:
  - retrato cru da miséria, com sexo, violência, doença e fome;
  - **o ambiente explica o indivíduo** (um determinismo social, diferente do biológico);
  - **linguagem coloquial e oral** ("Nós vai", "tu é", gírias como "porreta", "batuta", "canja");
  - mesmo assim, momentos **líricos e poéticos** sobre a Bahia (o carrossel, o mar, a lua). Essa mistura de **denúncia com lirismo** é típica de Jorge Amado.
- O livro também é um **romance proletário/engajado**: termina apontando uma solução política, a revolução.

### Pratique: página 2

1. Por que o livro foi queimado em 1937?
    - A) Por conter palavrões
    - B) Por ser considerado propaganda comunista pelo Estado Novo
    - C) Por criticar Lampião
    - D) Por plágio
    - *Resposta: B. Jorge Amado era comunista e o regime de Vargas apreendeu e queimou livros considerados subversivos.*
2. A que geração do Modernismo o livro pertence?
    - A) 1ª geração (1922)
    - B) 2ª geração, o Romance de 30
    - C) 3ª geração (1945)
    - D) Pré-Modernismo
    - *Resposta: B. É prosa regionalista e social da 2ª geração, o Romance de 30.*
3. Qual destes autores é da mesma geração de Jorge Amado?
    - A) Machado de Assis
    - B) Graciliano Ramos
    - C) Clarice Lispector
    - D) José de Alencar
    - *Resposta: B. Graciliano Ramos (Vidas Secas), Rachel de Queiroz e José Lins do Rego são do Romance de 30.*
4. Cite três marcas do neorrealismo presentes no livro.
    - *Resposta esperada: Retrato cru da miséria (fome, doença, sexo, violência); o ambiente explica o indivíduo (determinismo social); linguagem oral e coloquial ("nós vai", "porreta"); além de denúncia política misturada a momentos líricos.*
5. Onde a repressão do governo aparece dentro da história?
    - *Resposta esperada: Na polícia que tortura crianças e invade candomblés; no Cônego chamando o padre de comunista; no fim, com jornais clandestinos, partidos ilegais e Pedro Bala preso numa colônia.*


---

## 3. A abertura: as "Cartas à redação" (p. 1–16)

- **p. 1–2:** dedicatória a Matilde (esposa do autor) e a amigos, entre eles Anísio Teixeira, "amigo das crianças" (educador).

### ★ O que acontece
O livro abre como se fosse um **dossiê de jornal**. A sequência é esta:

1. **Reportagem do *Jornal da Tarde*.** Os Capitães da Areia assaltam o palacete do **Comendador José Ferreira**, no Corredor da Vitória. O chefe (reconhecido pelo **talho no rosto**) fere o jardineiro Ramiro com punhaladas. O menino rico **Raul**, neto do comendador, conta que o chefe riu dele e disse que ele não sabia brincar: Raul tinha bicicleta e brinquedos, o outro "tinha a rua e o cais". Raul diz que ficou "gostando dele", e o jornal culpa até o cinema. O jornal pede "providências" contra os "precoces criminosos".
2. **Carta do Secretário do Chefe de Polícia.** Diz que a culpa é do Juiz de Menores.
3. **Carta do Juiz de Menores.** Diz que a culpa é da polícia e que o Reformatório é um lugar de "paz e trabalho". Eles fogem "por quê?", pergunta, e deixa a questão para os psicólogos.
4. **Carta de Maria Ricardina, costureira e mãe.** Denuncia que no Reformatório os filhos dos pobres **apanham duas ou três vezes por dia, comem mal, fazem trabalho escravo** e que o diretor vive bêbado. Prefere o filho entre os Capitães da Areia.
5. **Carta do Padre José Pedro**, ex-capelão do Reformatório. Confirma: as crianças são "tratadas como feras".
6. **Carta do Diretor do Reformatório.** Despreza a "mulherzinha do povo", chama o padre de "padre do demônio" e **convida um redator para visitar numa segunda-feira**, dia marcado pelo regulamento, ou seja, com tudo preparado.
7. **Reportagem final:** "UM ESTABELECIMENTO MODELAR ONDE REINAM A PAZ E O TRABALHO... O REFORMATÓRIO É UMA GRANDE FAMÍLIA".

### Análise: a característica jornalística do início
- **A imprensa está a serviço dos ricos.** O detalhe está nas notas de rodapé de cada carta. A do chefe de polícia saiu na **1ª página, com foto e "comentário elogioso"**. A da costureira saiu na **5ª página, "entre anúncios, sem clichês e sem comentários"**. A do padre saiu na 3ª, com o título "Será Verdade?". O jeito de publicar já mostra quem tem voz.
- **Autoridades empurram a culpa uma para a outra** (polícia × juiz) e ninguém resolve.
- **Recurso de verossimilhança.** Parece documento real, dá ar de reportagem e ironiza a própria reportagem.
- **Polifonia.** Várias vozes sociais aparecem antes do narrador. Depois, o romance inteiro funciona como **resposta** a essas cartas: mostra "o outro lado" que o jornal esconde.
- O recurso **volta ao longo do livro**: a manchete da prisão de Pedro Bala (Dora vira "gigolete dos moleques"), a notícia da fuga, e o capítulo **"Notícias de jornal"**, com os destinos de Professor, Gato, Boa-Vida e Volta Seca.

### Pratique: página 3

1. Onde foi publicada a carta da costureira Maria Ricardina?
    - A) Na 1ª página, com foto
    - B) Na 5ª página, entre anúncios, sem foto e sem comentário
    - C) Na 3ª página, com o título "Será Verdade?"
    - D) Não foi publicada
    - *Resposta: B. A carta da mãe pobre ficou escondida entre anúncios. O chefe de polícia ganhou 1ª página com foto.*
2. O que o diretor do reformatório propõe ao jornal?
    - A) Fechar o reformatório
    - B) Uma visita de um redator numa segunda-feira marcada
    - C) Demitir os guardas
    - D) Adotar os Capitães
    - *Resposta: B. A visita com dia marcado permite preparar tudo; por isso a reportagem final chama o lugar de "modelar".*
3. O que o menino rico Raul diz sobre o chefe dos Capitães?
    - A) Que teve medo dele
    - B) Que o chefe tinha a rua e o cais, e que ficou gostando dele
    - C) Que o chefe roubou sua bicicleta
    - D) Que não o viu
    - *Resposta: B. Raul tinha bicicleta e brinquedos; o chefe "tinha a rua e o cais".*
4. Qual é a função das cartas no começo do livro?
    - *Resposta esperada: Imitar a imprensa, mostrar a versão oficial e sua hipocrisia (quem ganha destaque e quem é escondido), dar tom documental e deixar que o resto do romance funcione como resposta, mostrando o outro lado.*
5. Quem culpa quem na troca de cartas entre as autoridades?
    - *Resposta esperada: A polícia diz que é função do Juiz de Menores; o juiz diz que capturar é função da polícia. Ninguém resolve.*


---

## 4. A história, Parte 1: "Sob a lua, num velho trapiche abandonado"

> Esta parte apresenta o grupo, sua ética, suas dores e aventuras, e o começo do despertar de Pedro Bala.

### O trapiche (p. 17–19)
**Quem aparece:** Pedro Bala, Raimundo (o Caboclo), Barandão.

- **p. 17–18:** o trapiche era um armazém à beira do cais, antes porto de veleiros e de trabalho de ex-escravos. A areia fez o mar recuar e ele foi abandonado, ficando com ratos e um cachorro vagabundo, até os meninos ocuparem o lugar. Lá também guardam o que roubam.
- **p. 18–19:** ★ **Pedro Bala** tem 15 anos, está na rua há 10, nunca conheceu a mãe e o pai morreu "de um balaço". Tomou a chefia de **Raimundo, o Caboclo**. Raimundo cortou o rosto dele com navalha (daí a **cicatriz**). Depois Pedro defendeu o negrinho Barandão e venceu Raimundo, que foi embora do areal.
- O grupo tem uns **100 meninos, de 8/9 a 16 anos, "de todas as cores"**, e uns 40 dormem ali. O narrador os define como "os donos da cidade... os seus poetas".

### Noite dos Capitães da Areia (p. 20–40)
**Quem aparece:** João Grande, Professor, Sem-Pernas, Gato, Pirulito, Boa-Vida, Dalva, Barandão, Almiro, Volta Seca, Pedro Bala.

É o capítulo que apresenta cada menino:

- **p. 20–22:** **João Grande** volta de beber na Porta do Mar com o **Querido-de-Deus**, que dá aulas de capoeira a ele, Pedro Bala e Gato. Ele entrou no grupo aos 9 anos, depois que o pai carroceiro morreu atropelado por um caminhão. Dorme na porta com o punhal na mão, "como um cão de fila".
- **p. 22–23:** **Professor** lê à vela; ganhou o apelido pelas mágicas e pelas histórias. O narrador **já antecipa** que ele vai pintar quadros que "assombrariam o país".
- **p. 23–24:** **Gato** mostra o anelão de pedra falsa roubado no bonde de Brotas, e Sem-Pernas zomba dele.
- **p. 24–26:** reunião dos chefes: roubo de **chapéus de feltro** para o receptador **Gonzales do 14**. Pedro guarda João Grande e Gato para "um negócio do Querido-de-Deus".
- **p. 26–27:** o canto de **Pirulito** (santos, flor, cravo roubado), que reza pedindo para entrar no seminário.
- ★ **p. 27–30:** **Sem-Pernas** vê Pirulito rezando e sente "inveja e desespero". Suas crueldades: torturou um gato, cortou um garçom por causa de um frango, abriu o próprio abscesso rindo. **O trauma:** foi criado por um padeiro que o surrava; na cadeia, soldados bêbados o fizeram correr com a perna coxa, batendo com borracha, enquanto **um homem de colete cinzento ria**. Ele sonha com uma bomba que arrasasse a cidade, ou com uma mulher que o acarinhasse.
- **p. 30:** um grupo de quatro chega contando vantagem sobre uma menina, e Sem-Pernas debocha.
- **p. 30–32:** o **Gato** veio de Aracaju, onde vivia com os Índios Maloqueiros. **Boa-Vida** tentou seduzi-lo, depois forçá-lo, e levou uma rasteira ("Eu sou é homem"). Os dois fazem as pazes.
- ★ **p. 32–37:** **Gato e Dalva.** Ele espia **Dalva**, prostituta de uns 35 anos, todas as noites. O amante dela, o flautista Gastão, a abandona. Gato leva o recado dela, encontra Gastão com outra mulher, rouba a bolsa dessa mulher, volta e passa a noite com Dalva, que lhe diz "O frangote parece um homem". Por isso o Gato sai toda meia-noite.
- **p. 37–38:** Sem-Pernas olha os meninos dormindo e pensa que "a alegria daquela liberdade era pouca para a desgraça daquela vida". Doenças sem remédio; às vezes aparecem o padre, Don'Aninha ou o Querido-de-Deus.
- ★ **p. 38:** **Barandão e Almiro** juntos no areal. Sem-Pernas conclui: **"Todos procuravam um carinho"** (Professor nos livros, Gato na mulher, Pirulito na reza) e sai correndo pelo areal.
- **p. 38–39:** Pedro Bala pega um menino **mexendo no baú de Pirulito** e ameaça expulsá-lo para o grupo de **Ezequiel** (primeira menção). O menino queria a medalha para uma menina que foi boa com ele, e **Pirulito dá a medalha**.
- **p. 39–40:** **Volta Seca** pede ao Professor que leia a notícia de **Lampião** (vila atacada, soldados mortos) e guarda o retrato do bando.

### Ponto das Pitangueiras (p. 41–54)
**Quem aparece:** Pedro Bala, João Grande, Gato, Querido-de-Deus.

- **p. 41–45:** treino de capoeira na Porta do Mar. Gato ganha no baralho marcado do Querido-de-Deus e de dois marinheiros (João Grande e Pedro fingem perder para enganá-los). Depois **devolve os 5 mil-réis** do amigo ("tinha trapaça").
- **p. 45–47:** o homem do "negócio" não aparece; o intermediário marca um encontro de madrugada. Os três comem sarapatel e feijoada pagos pelo Gato.
- ★ **p. 47–51:** o cliente, **Joel**, quer trocar um **pacote de cartas de amor** (de uma mulher casada, "Elisa") que um empregado usaria para chantagem. Ele desconfia porque "são uns meninos". Pedro negocia de 100 para 150 mil-réis, e Gato exige adiantamento.
- ★ **p. 51–54:** o cachorro é atraído para a rua; o empregado está sentado em cima do pacote; João Grande toca a campainha e Pedro troca o pacote. Depois João Grande **sobe pela calha para consolar a mulher**, que chorava na janela ("Deus ia me ajudar", diz ela). Termina com a "gargalhada dos Capitães da Areia, que era como um hino do povo da Bahia".

### ★ As luzes do carrossel (p. 55–74)
**Quem aparece:** Nhozinho França, Volta Seca, Sem-Pernas, Padre José Pedro, Boa-Vida, Professor, Pedro Bala, viúva Margarida Santos.

**O que acontece:**
- **p. 55–57:** história de **Nhozinho França**: bebeu o parque inteiro e ficou só com o velho carrossel "Grande Japonês". **Lampião e o bando andaram nele** e, felizes como crianças, pouparam a vila do saque.
- **p. 57–59:** Nhozinho contrata **Volta Seca** (anuncia o público vestido de cangaceiro, imitando bichos) e **Sem-Pernas** (cuida do motor). Antes, Sem-Pernas tinha sido expulso de um parque por estar de farrapos e roubou a bilheteria. Agora vê Nhozinho "como a um ídolo", "algo como Deus", e **chora de alegria pela primeira vez**.
- ★ **p. 59–61:** quase cem meninos diante do carrossel. Volta Seca toca uma valsa antiga na pianola; um operário para para ouvir; os meninos **"amaram-se uns aos outros, se sentiram irmãos"**.
- **p. 61–63:** a noite de sábado com o carrossel funcionando. **Volta Seca** roda no cavalo onde Lampião montou e, na imaginação, **mata soldados e fazendeiros**. **Sem-Pernas** vai ao carrossel "como um crente para uma missa", no cavalo azul estrelado, e sente que é como "aqueles meninos que têm pai e mãe".
- **p. 63–68:** história do **Padre José Pedro**: ex-operário de fábrica de tecidos, seminário difícil, briga com as beatas e com o padre Clóvis, o plano fracassado de entregar meninos a beatas. Ele conheceu o grupo pelo **Boa-Vida, pego tentando roubar um relicário** na sacristia.
- ★ **p. 68–71:** o padre oferece **50 mil-réis tirados do dinheiro de velas** da igreja para os meninos andarem no carrossel. Eles recusam com delicadeza; João Grande percebe de onde veio o dinheiro, e Sem-Pernas se oferece para devolvê-lo.
- **p. 71–72:** Professor desenha Volta Seca de cangaceiro. Ele ganha trocados desenhando a giz nas calçadas.
- ★ **p. 72–74:** a **viúva Margarida Santos** humilha o padre por andar com a "gentalha" ("Isso não são crianças, são ladrões"). De madrugada, os meninos giram no carrossel e "foram iguais a todas as crianças". O padre pensa: **"Eram crianças, sim"**.

**Análise:** é o **único momento em que são crianças de verdade**. O carrossel mostra que **eles são crianças obrigadas a ser homens**. A cena opõe a visão da viúva (ladrões) à do padre (crianças), e junta os meninos numa irmandade pela música.

### Docas (p. 75–88)
**Quem aparece:** Pedro Bala, Boa-Vida, Pirulito, João de Adão, Luísa (negra velha), Querido-de-Deus, uma menina de 15 anos.

**O que acontece:**
- **p. 75–76:** jogo de moedas na parede da Alfândega. Pedro Bala quer ser marinheiro; Boa-Vida quer ser malandro na Bahia.
- ★ **p. 76–79:** **João de Adão**, estivador e antigo grevista, e a negra **Luísa** contam que **o pai de Pedro, Raimundo, "o Loiro", morreu com um tiro numa greve nas docas**, quando a cavalaria atacou. A mãe era de família rica da cidade alta e morreu quando ele tinha 6 meses. João diz que há "um lugar pra tu nas docas". Pedro diz: "Eu gostava de fazer uma greve".
- **p. 79–80:** Pedro olha os estivadores e o chão onde o pai sangrou e decide que um dia fará uma greve como ele.
- **p. 80–81:** no candomblé do Gantois, **Omolu anuncia a vingança dos pobres**.
- ★ **p. 81–88: o estupro.** Perturbado, Pedro persegue uma **menina negra de 15 anos, virgem**, derruba-a na areia e a violenta (por trás, prometendo deixá-la "donzela"). Depois a acompanha e sente **vergonha e tristeza**. Ela o amaldiçoa ("Peste, fome e guerra te acompanha") e cospe no chão. Ele corre para o mar e escuta dentro de si: **"Uma criança também"**.

**Análise:**
- É onde começa a **consciência de classe** de Pedro: ele descobre que o pai morreu lutando pelos "direitos" dos doqueiros.
- O estupro mostra que o herói **não é idealizado**: a violência que ele sofre ele também reproduz. O narrador diz que o desejo nascia "da vontade de afogar a angústia".
- A frase "Uma criança também" é o **primeiro reconhecimento da vítima como igual**. A cena contrasta depois com o amor por Dora, que ele respeita. (Mais em "As meninas do areal", na página 8.)

### ★ Aventura de Ogum (p. 89–103)
**Quem aparece:** Don'Aninha, Pedro Bala, Sem-Pernas, João Grande, Professor, Gato, o homem do sobretudo, o comissário.

**O que acontece:**
- **p. 89–91:** a polícia leva a imagem de **Ogum** de um candomblé protegido por **Don'Aninha**. Um professor da Faculdade de Medicina quer a imagem para a **própria coleção**, não para devolver ao culto. Don'Aninha protesta: "Não deixam nem o deus dos pobres em paz". Pedro promete trazer Ogum.
- **p. 91–92:** noite de temporal no trapiche; os pequenos têm medo e sentem falta de "palavra de mãe".
- ★ **p. 92–94:** como o **Professor ganhou o sobretudo**: desenhou um homem de sobretudo, levou pontapés, depois cortou a mão do homem com navalha e ficou com o sobretudo. É **a origem do vilão dos quadros dele**.
- **p. 95–96:** Pedro avisa o grupo que pode ser preso; Volta Seca pensa que Pedro será corajoso como Lampião.
- ★ **p. 96–103:** Pedro pede para dormir na polícia, **finge roubar para ser preso**, enrola Ogum no paletó e dorme em cima. Na sala de detidos, presos zombam de "Mariazinha", um velho chora dizendo que não fez nada, um jovem negro volta com as mãos inchadas de palmatória. O comissário vaidoso (rubi no dedo, pretensões literárias) confere o nome "Augusto Santos", saveirista de Mar Grande, no registro e o solta. Pedro confessa: "Tive um cagaço da desgraça".

**Análise:** mostra a **perseguição à religião afro-brasileira** (o candomblé era reprimido), a **inteligência** dos meninos contra a "autoridade" e a **lealdade** de Pedro a quem ajuda os pobres. O medo confessado lembra que ele ainda é menino.

### ★ Deus sorri como um negrinho (p. 104–111)
**Quem aparece:** Pirulito, Padre José Pedro, João de Adão, João Grande, Professor, Don'Aninha.

**O que acontece:**
- **p. 104–106:** Pirulito vive dividido entre o **Deus bondoso** do padre José Pedro e o **Deus que castiga** do sermão de um frade alemão.
- **p. 106–107:** debate: o padre diz que "a culpa era da vida"; João de Adão diz que a culpa é "da sociedade mal organizada, dos ricos" e que só a revolução resolve. O padre às vezes concorda com João de Adão e se assusta com isso.
- **p. 107:** Pedro Bala **expulsa os pederastas passivos** do grupo, por pressão do padre e do Querido-de-Deus.
- **p. 107–108:** o passado de Pirulito: já foi dos mais malvados, mas uma vez defendeu um gato que Chico Banha torturava. Ele se converte, dá a navalha ao menino em quem bateu e passa a jejuar.
- **p. 108:** o **bebê negro** abandonado, alimentado por João Grande e Professor e levado por Don'Aninha.
- ★ **p. 108–111: o roubo da Virgem.** Pirulito tinha jurado só roubar para comer ou por ordem do grupo. Diante de uma imagem da **Virgem da Conceição com o Menino magro e nu**, um "Deus Pobre" que ninguém queria comprar, sente que a Virgem o oferece a ele. Rouba a imagem, que "sorri como um negrinho", como o bebê do trapiche.

**Análise:** o conflito entre fé e culpa; a religião vista **do lado dos pobres** (o Menino pobre, como eles); o "pecado" justificado pelo amor. O debate padre × João de Adão já apresenta as duas saídas do livro: **caridade ou revolução**.

### ★ Família (p. 112–129)
**Quem aparece:** Sem-Pernas, Dona Ester, Raul, a empregada Maria José, Pedro Bala, Boa-Vida, Gato, Barandão, Professor.

**O que acontece:**
- **p. 112–114:** Boa-Vida indica uma casa rica na Graça. Pedro Bala seduz a empregada **Maria José** e passa a noite com ela.
- ★ **p. 114–118:** Sem-Pernas finge ser órfão na casa de **Dona Ester**, que perdeu o filho **Augusto**. Por acaso, Sem-Pernas diz que se chama Augusto. Ela abre a mala do filho morto e o veste com a **roupa de marinheiro**.
- **p. 118–121:** ele é tratado como hóspede querido, tem **medo de que sejam bons com ele** (sem o ódio "não terá nenhum motivo para viver") e fuma de propósito debaixo da janela para ser mandado à cozinha. O marido, **Raul**, advogado e colecionador, promete "fazer dele um homem" e uma bicicleta. Cinema e sorvete; ele quase pede cerveja.
- ★ **p. 121–122:** o **beijo de boa-noite** de Dona Ester, "uma carícia de mãe".
- **p. 123–124:** Pedro vem cobrar; Sem-Pernas está de roupa de casimira e perfumado e mente que "os troço melhor tão trancado". Notícia: **o Gringo quase morreu**, e Don'Aninha o salvou.
- ★ **p. 124–126:** ele se sente **traidor** dos dois lados (como o doqueiro fura-greve de que fala João de Adão), decide pela lealdade ao grupo e chora no colo de Dona Ester.
- **p. 126–127:** Raul viaja ao Rio. Sem-Pernas beija Dona Ester pela primeira vez ("A senhora é muito boa. Eu nunca vou esquecer") e vai embora. O grupo rouba a casa.
- **p. 127–129:** ele troca a roupa boa pela do Gato, tem pesadelo com Dona Ester dizendo que ele é ladrão e **recusa sua parte** do dinheiro. O jornal publica que a família **procura o filho "Augusto" desaparecido**. Barandão zomba, Sem-Pernas quase o esfaqueia e depois chora.

**Análise:** a **tragédia de Sem-Pernas**: quando finalmente recebe amor, **não consegue aceitar**, porque a vida já o marcou demais. É uma **exceção ao maniqueísmo** (ricos bons) e mostra a **lei do grupo** acima do desejo pessoal.

### ★ Manhã como um quadro (p. 130–138)
**Quem aparece:** Pedro Bala, Professor, Dr. Dantas (o homem da piteira), um guarda.

**O que acontece:**
- **p. 130–133:** Pedro e Professor sobem a ladeira felizes (cumprimentam Coruja Branca). Professor quer pintar coisas alegres, mas os rostos dos pobres **"saem tristes"**. Ele já entrou escondido na Escola de Belas-Artes; Pedro propõe que o grupo pague a escola.
- **p. 133–134:** cantam com um homem de violão.
- **p. 134–135:** desenhos a giz na Rua Chile: o casal de noivos, a velha feia retratada feia.
- ★ **p. 135–137:** o **homem da piteira**, desenhado sentado no ar lendo um livro, reconhece "uma verdadeira vocação" e dá o **cartão** e a piteira. O guarda: "São ladrões". O homem lamenta: "Assim que se perdem os grandes artistas".
- ★ **p. 137–138:** Professor usa o cartão para limpar a piteira e o joga fora: **"do meio da gente só pode sair ladrão"**.

**Análise:** o **talento desperdiçado pela exclusão**, sem escola nem oportunidade. Depois da morte de Dora, o Professor **procura** esse homem, o Dr. Dantas, e vai ao Rio virar pintor (ver "Vocações", na página 6).

### ★ Alastrim (p. 139–160)
**Quem aparece:** Almiro, Barandão, Sem-Pernas (e seu cachorro), Volta Seca, Pirulito, Pedro Bala, Professor, João Grande, Padre José Pedro, o médico, o Cônego, Boa-Vida.

**O que acontece:**
- **p. 139–140:** a visão mítica: Omolu mandou a "bexiga negra" para a cidade alta, **mas os ricos se vacinaram**, e ela desceu para a cidade dos pobres. Omolu teve pena e a transformou em **alastrim** (a varíola mais branda). Os doentes são levados em sacos para o **lazareto**, onde ninguém é visitado e de onde ninguém volta.
- ★ **p. 140–146:** **Almiro** pega a doença. Barandão sai gritando. **Sem-Pernas** quer jogá-lo na rua para a Saúde Pública recolher (e não revelar o trapiche) e chega a chutá-lo; Pirulito diz que é "castigo de Deus". **Volta Seca** o defende de revólver: "É um do grupo". **Pedro Bala** chega e **recusa o lazareto**; quando o padre diz "é a lei", Pedro responde: "Morrer?". Levam Almiro para a casa da mãe, o padre traz um médico, e o médico, querendo **um cargo na Saúde Pública, denuncia o caso**. Almiro vai para o lazareto e **morre**.
- ★ **p. 147–156:** o **padre diante do Cônego**: acusado de ter ajudado a vaiar a viúva Santos e de esconder a varíola, é chamado de **"comunista"** e **perde a paróquia**. Anda pela rua em crise, ajoelha, e o chamam de "padre bêbado".
- ★ **p. 156–158:** **Boa-Vida** pega a doença e **vai sozinho ao lazareto** para não contaminar ninguém ("Não me faz cheio de bexiga", pede ao Professor sobre o retrato). Sem-Pernas se fecha ainda mais depois da morte de Almiro.
- **p. 158:** Omolu "pula na máquina da Leste Brasileira" e leva a bexiga para os **latifundiários do sertão**.
- ★ **p. 159–160:** Boa-Vida **volta vivo**, magro e marcado: o lazareto é "igual que entrasse pro caixão". Professor vê nele "uma estrela no lugar do coração".

**Análise:** a doença é **social** (vacina para rico, lazareto para pobre). Mostra o **Estado que exclui**, o **sincretismo** (Omolu × vacina) e a **solidariedade** do grupo (Volta Seca, Pedro, Boa-Vida). A varíola também **mata os pais de Dora** e faz ela ser rejeitada, ligando a Parte 1 à Parte 2.

### Destino (p. 161–162)
**Quem aparece:** Pedro Bala, João de Adão, um velho, Professor, João Grande, Boa-Vida.

- ★ Na Porta do Mar, um velho diz que **"ninguém pode mudar o destino"**. João de Adão responde: "Um dia a gente muda o destino dos pobres". Pedro Bala repete, e João diz: **"É filho do Loiro, fala a voz do pai"**.
- **Análise:** fecha a Parte 1 anunciando a ideia central do livro: o destino dos pobres pode mudar.

### Pratique: página 4

1. Como Pedro Bala ganhou a cicatriz no rosto?
    - A) Numa briga com Ezequiel
    - B) Com a navalha de Raimundo, o Caboclo, antigo chefe
    - C) Na tortura da polícia
    - D) Caindo do trapiche
    - *Resposta: B. Raimundo cortou seu rosto; depois Pedro o venceu defendendo Barandão e tomou a chefia.*
2. No carrossel, o padre José Pedro oferece dinheiro que tirou de onde?
    - A) Do próprio salário
    - B) Do dinheiro das velas doado por uma viúva
    - C) De uma coleta dos fiéis
    - D) Do Cônego
    - *Resposta: B. Ele tirou 50 mil-réis dos 500 que uma viúva deu para velas; os meninos recusam com delicadeza.*
3. O que João de Adão revela a Pedro Bala nas docas?
    - A) Que a mãe dele está viva
    - B) Que o pai dele, o Loiro, morreu com um tiro numa greve
    - C) Que ele tem um irmão
    - D) Que Raimundo era seu pai adotivo
    - *Resposta: B. O pai morreu lutando pelos direitos dos doqueiros quando a cavalaria atacou a greve.*
4. Como Pedro Bala recupera a imagem de Ogum?
    - A) Invade a delegacia de madrugada
    - B) Se deixa prender, esconde a imagem no paletó e engana o comissário
    - C) Paga um guarda
    - D) Pede ao padre
    - *Resposta: B. Finge roubar para ser preso, dorme sobre a imagem e se diz filho do saveirista Augusto Santos.*
5. Por que Sem-Pernas vai embora da casa de Dona Ester?
    - A) Foi expulso
    - B) Por lealdade ao grupo, mesmo sofrendo
    - C) Porque Raul descobriu
    - D) Porque ficou doente
    - *Resposta: B. Ele sente que estaria traindo os Capitães, beija Dona Ester, sai e o grupo rouba a casa.*
6. Quem defende Almiro de revólver quando Sem-Pernas quer expulsá-lo?
    - A) João Grande
    - B) Volta Seca
    - C) Pirulito
    - D) Professor
    - *Resposta: B. Volta Seca: "É um do grupo".*
7. Por que o carrossel é tão importante?
    - *Resposta esperada: É o único momento em que os meninos são só crianças; eles se sentem irmãos com a música. Mostra que são crianças obrigadas a viver como homens (a viúva diz "ladrões", o padre pensa "eram crianças, sim").*
8. O que significa a frase que Pedro Bala ouve depois do estupro: "Uma criança também"?
    - *Resposta esperada: Ele reconhece que a menina é tão vítima e tão criança quanto ele. Mostra que o herói também é agressor e é o começo da culpa e da consciência.*
9. Qual é a origem do "homem de sobretudo" dos quadros do Professor?
    - *Resposta esperada: Um homem de sobretudo chutou o Professor por causa de um desenho; o Professor se vingou cortando a mão dele com navalha e ficou com o sobretudo. Esse homem vira o símbolo do mal nos quadros.*
10. Por que a varíola é uma doença "social" no livro?
    - *Resposta esperada: Os ricos se vacinam e a doença desce para os pobres; e o que mata é o lazareto, para onde os pobres são levados e de onde ninguém volta.*


---

## 5. A história, Parte 2: "Noite da grande paz, da grande paz dos teus olhos"

> A parte de Dora. Ela chega, humaniza o grupo como mãe, irmã, noiva e esposa, e morre.

### ★ Filha de Bexiguento (p. 163–175)
**Quem aparece:** Dora, Zé Fuinha, Estêvão e Margarida (os pais), Dona Laura e o filho Emanuel, João Grande, Professor, Gato, Boa-Vida, Sem-Pernas, Volta Seca, Pedro Bala.

**O que acontece:**
- **p. 163–164:** o morro de luto pela varíola. Morrem **Estêvão** (o pai, no lazareto) e depois **Margarida** (a mãe, lavadeira, que recaiu por trabalhar doente). O dono dos barracões aluga o barraco no dia seguinte.
- ★ **p. 164–168:** **Dora** (13–14 anos, loira, neta de italiano com mulata) desce com o irmão **Zé Fuinha** (6 anos) e anda até a Barra atrás de emprego. **Dona Laura**, antiga patroa da mãe, recusa quando ouve "bexiga", dá 2 mil-réis e **manda passar álcool no portão**, enquanto o filho Emanuel olha o corpo da menina.
- **p. 168–169:** ela procura emprego a tarde inteira: "Ninguém quer filha de bexiguento".
- **p. 169–170:** Dora divide o pão com **João Grande e Professor**, que a levam ao trapiche.
- ★ **p. 170–175:** a maioria dos meninos quer **violentá-la em grupo**. João Grande e Professor a defendem com punhal e navalha; Volta Seca corta o Professor, João Grande derruba Boa-Vida. Pedro Bala chega e, no primeiro momento, diz **"Tão com o direito"**. João Grande grita que ela "é uma menina", e Pedro **muda de lado**. Dora cuida das feridas de todos, inclusive dos agressores; o cachorro de Sem-Pernas lambe os pés dela; ela fica.

**Análise:** mostra o **preconceito** (Dona Laura) e o **Estado ausente**. A cena do trapiche é o espelho da menina do areal: desta vez a violência é impedida, e Pedro aprende a **respeitar**.

### Dora, Mãe (p. 176–186)
**Quem aparece:** Dora, Gato, Professor, João Grande, Volta Seca, Pirulito, Pedro Bala.

- ★ **p. 176–178:** Dora costura a camisa do **Gato**, que sente a **mãe morta voltar**: "Você é a mãezinha da gente".
- **p. 178–180:** Professor lê a história de um motim de marinheiros (John e James) e todos riem juntos com Dora.
- ★ **p. 180–182:** **Volta Seca** diz que Dora lembra a mãe dele, sertaneja valente. Notícia no jornal: Lampião foi emboscado porque um chofer avisou a vila, e a **cabeça de um cangaceiro foi cortada**. Dora: "Que judiaria!". Volta Seca: "Já tá em tempo d'eu ir".
- **p. 182–185:** **Pirulito**, que via Dora como pecado, conta a ela que quer ser padre e lhe dá o Menino Deus roubado.
- **p. 185–186:** no areal, Pedro quer que ela vá embora; Professor insiste: "É como uma mãe". Pedro deixa ficar. Professor percebe o amor entre os dois.

**Análise:** os meninos encontram **o afeto de mãe que nunca tiveram**. Cada um vê em Dora a mãe que perdeu.

### Dora, Irmã e Noiva (p. 187–195)
**Quem aparece:** Dora, Pedro Bala, João Grande, Professor, Ezequiel e seu grupo, Sem-Pernas, Barandão, Volta Seca, Boa-Vida.

- **p. 187–189:** Dora troca o vestido por calças e passa a **roubar junto**: "Como se vocês fosse tudo uns homão. É tudo uns menino". Vira **irmã** dos maiores; João Grande a segue "como um cachorro". **Professor também a ama em segredo.**
- ★ **p. 189–191:** **Ezequiel** e mais três (um deles, ex-Capitão expulso por roubar colega) surram Pedro por terem chamado Dora de "putinha".
- ★ **p. 191–192:** Dora cuida dele e **o beija**. Pedro: **"Tu agora é minha noiva"**.
- ★ **p. 193–195:** vingança no **Porto da Lenha** com uns 30 meninos, Dora lutando junto ("parece Rosa Palmeirão"). À noite, Pedro e Dora dormem de mãos dadas "como dois irmãos".

**Análise da gangue de Ezequiel:** é um grupo "muito menor" e "muito mais sem ordem", que **"vive roubando uns dos outros"** e vive "todo dia na cadeia". Ser expulso dos Capitães significava ir para Ezequiel ou acabar no reformatório. Serve de **contraste**: os Capitães têm **"uma lei e uma moral, um sentido de dignidade humana"** (não roubam entre si, só sacam a arma se o outro sacar, defendem os fracos).

### ★ Reformatório (p. 196–217)
**Quem aparece:** Pedro Bala, Dora, João Grande, Sem-Pernas, Gato, polícia, investigador, o Diretor do Reformatório, os bedéis Ranulfo, Fausto e Campos, Jeremias, Agostinho, Henrique (delator), o *Jornal da Tarde*.

**O que acontece:**
- ★ **p. 196–198:** num assalto frustrado à casa do Dr. Alcebíades (ladeira de São Bento), são presos Pedro, Dora, João Grande, Sem-Pernas e Gato. Pedro derruba um investigador **com golpe de capoeira** e os outros fogem. O jornal chama Dora de "gigolete" e depois de "noiva"; o diretor garante que Pedro "se reformará". **Dora vai para o Orfanato.** Sem-Pernas vira chefe provisório.
- ★ **p. 199–200:** **tortura** na polícia (chicote, socos, pontapés, até do diretor) para Pedro contar onde fica o trapiche. **Ele não conta** e desmaia.
- **p. 200–201:** a canção dos presos na madrugada: **"a liberdade é o bem maior do mundo"**. Pedro liga isso à luta do pai.
- ★ **p. 202:** o diretor o chama de **"criminoso nato"**, citando **Lombroso** ("traz todos os estigmas do crime na face"), e manda para a **cafua** a "**Regime número 3**": água e feijão.
- ★ **p. 203–209:** **oito dias na cafua**, um cubículo embaixo da escada onde **não dá para ficar em pé nem deitado esticado**, no escuro, com ratos, um barril de fezes, sede e feijão salgado. Tem alucinações com Dora morrendo. Um menino de fora passa **cigarros** por baixo da porta e é esbofeteado por isso.
- **p. 209–211:** sai **esquelético**, tem a cabeça loira raspada, recebe uniforme de mescla azul e vai cortar **cana** debaixo de socos dos bedéis.
- **p. 211–214:** no dormitório: reza obrigatória, a **delação** de Henrique, castigo coletivo, pederastia. Um menino quer entrar para os Capitães.
- **p. 214–215:** revolta de **Jeremias** contra o bedel Fausto; **Agostinho** foge, é recapturado e surrado na frente de todos; os dois ficam **juntos na cafua**.
- ★ **p. 215–217: a fuga.** Sem-Pernas deixa **uma corda com um punhal** no canavial. Pedro desce do 3º andar pela janela, emendando o lençol na corda com nó ensinado pelo Querido-de-Deus. Um delator grita. Ele **tira a roupa para os cães não o farejarem** e foge **nu**, "para o sol, para a liberdade". O jornal noticia a fuga, e até o padre ri com os meninos.

**Análise:** desmente a reportagem do "estabelecimento modelar" do início. É a **crítica ao Estado**, que "reforma" com tortura, e desmonta o **determinismo biológico** de Lombroso (o livro defende o determinismo **social**). É onde Pedro aprende que a liberdade é o bem maior e a liga à luta do pai.

### ★ Orfanato (p. 218–219)
**Quem aparece:** Dora, uma freira, Pedro Bala, João Grande, Gato, Professor, Volta Seca.

- Um mês bastou para "matar a alegria e a saúde de Dora": cabelo em **tranças com fita cor-de-rosa**, aula com meninas de 5 anos, comida ruim, jejum de castigo, perda do recreio. Adoece; a enfermaria é "sempre crepúsculo", "ante-sala do túmulo". Recebe bilhetes pela grade.
- **Resgate:** Professor ameaça a freira com navalha, Volta Seca segura o cachorro com um pedaço de carne, e o grupo a leva, com febre.
- **Análise:** é o **equivalente feminino do reformatório**: a instituição mata a liberdade que a mantinha viva.

### Noite de Grande Paz (p. 220)
- Don'Aninha reza contra a febre com galho de sabugueiro. Os meninos olham em silêncio sua "mãe, irmã e noiva"; a "grande paz" da noite está nos olhos de Dora.

### ★ Dora, Esposa (p. 221–225)
**Quem aparece:** Dora, Pedro Bala, João Grande, Professor, Padre José Pedro, Pirulito, Don'Aninha, Querido-de-Deus, Sem-Pernas, Volta Seca, Zé Fuinha.

**O que acontece:**
- ★ **p. 221–224:** com febre, Dora coloca a mão de Pedro no seu seio: "Foi no orfanato... Agora posso ser tua mulher" (menstruou no orfanato). Ele recusa ("tu tá doente"); ela insiste: **"Antes de eu morrer"**. Os dois se entregam; ela "parecia não sentir a dor da posse", só paz. **Morre de madrugada.** João Grande: "Tu não devia ter feito". Pedro: "Foi ela que quis". O padre reza; Pirulito põe uma flor roxa nas mãos dela.
- ★ **p. 224–225:** a morte não pode ser comunicada sem revelar o trapiche. **Don'Aninha** envolve o corpo numa toalha branca de rendas ("Vai para Yemanjá"); o padre, contrariado, aceita; Pedro se agarra ao corpo; Professor diz: "Eu também gostava dela". O **Querido-de-Deus** leva o corpo no saveiro e o joga no mar.

**Análise:** é o **oposto do estupro**: amor consentido, desejado por ela. Completa o ciclo **mãe → irmã → noiva → esposa**. O sexo aparece como ternura e despedida, uma "coisa que não é de criança" vivida por crianças.

### ★ Como uma estrela de loira cabeleira (p. 226–227)
**Quem aparece:** Pedro Bala, Querido-de-Deus, Dora (como estrela).

- Pedro **não suporta perder Dora**, sua única família. **Se joga no mar** e nada atrás do saveiro para "se reunir a ela" com Yemanjá, até perder as forças. Boiando, vê um **cometa** e acredita que é **Dora virando estrela** de "longa cabeleira loira" (na lenda do cais só homens valentes viram estrela; Dora seria a primeira mulher). Isso lhe dá novas forças e **o saveiro do Querido-de-Deus o recolhe**.
- **Análise:** é a **tentativa de suicídio** de Pedro e, ao mesmo tempo, seu renascimento. A estrela passa a guiá-lo pelo resto do livro.

### Pratique: página 5

1. Por que Dora não consegue emprego?
    - A) Por ser muito nova
    - B) Porque os pais morreram de varíola e ninguém quer "filha de bexiguento"
    - C) Porque não sabia ler
    - D) Porque fugiu de casa
    - *Resposta: B. Dona Laura até manda passar álcool no portão onde ela encostou.*
2. Quem defende Dora quando os meninos querem violentá-la?
    - A) Pedro Bala e Gato
    - B) João Grande e Professor
    - C) Volta Seca e Boa-Vida
    - D) Sem-Pernas
    - *Resposta: B. João Grande e Professor. Pedro primeiro concorda com o grupo e depois muda de lado.*
3. Para o Gato, Dora é principalmente…
    - A) A noiva
    - B) A mãe que ele perdeu
    - C) Uma inimiga
    - D) Uma cúmplice nos golpes
    - *Resposta: B. Quando ela costura a camisa dele, ele sente a mãe morta voltar.*
4. O que é a "cafua"?
    - A) A cela do orfanato
    - B) Um cubículo embaixo da escada do reformatório onde não dá para ficar em pé
    - C) O nome do trapiche
    - D) A prisão da polícia
    - *Resposta: B. Pedro passa 8 dias lá, com água e feijão salgado ("regime número 3").*
5. Como Pedro foge do reformatório?
    - A) Pelo portão, de dia
    - B) Desce do 3º andar por uma corda e foge nu para os cães não o farejarem
    - C) Escondido num caminhão
    - D) O padre o tira de lá
    - *Resposta: B. Sem-Pernas deixou a corda com um punhal no canavial.*
6. O que acontece com o corpo de Dora?
    - A) É enterrado no cemitério
    - B) É levado no saveiro do Querido-de-Deus e jogado no mar
    - C) Fica no orfanato
    - D) É levado pela polícia
    - *Resposta: B. Don'Aninha o envolve para Yemanjá; um enterro revelaria o trapiche.*
7. Quais são os quatro papéis de Dora no grupo?
    - *Resposta esperada: Mãe (para os menores e para Gato, Volta Seca, Pirulito), irmã (para os maiores), noiva e esposa (para Pedro Bala).*
8. Por que o diretor chama Pedro de "criminoso nato" e o que o livro pensa disso?
    - *Resposta esperada: Ele cita Lombroso (determinismo biológico: o crime estaria no rosto). O livro defende o contrário: o ambiente social faz o criminoso.*
9. Compare o estupro no areal com a noite de Pedro e Dora.
    - *Resposta esperada: No areal há violência contra uma menina que implora; com Dora é amor consentido e pedido por ela. Mostra a mudança de Pedro: da violência ao respeito e ao amor.*
10. Por que Pedro Bala se joga no mar e o que o salva?
    - *Resposta esperada: Não suporta perder Dora, sua única família, e quer ir com ela. Vê um cometa, acredita que é Dora virando estrela, ganha forças e o saveiro do Querido-de-Deus o recolhe.*


---

## 6. A história, Parte 3: "Canção da Bahia, canção da liberdade"

> Depois de Dora, "a vida do trapiche acabou" para os mais velhos. Cada um segue a sua vocação: arte, religião, malandragem, golpe, cangaço, morte, mar e revolução. O grupo não acaba: com Barandão, continua, agora politizado. Cada destino mostra uma **resposta possível** à miséria: o livro defende que só a luta coletiva muda o destino, e as outras saídas são individuais, fracassadas ou incompletas.

### ★ Vocações (p. 228–235)
**Quem aparece:** Professor, Dr. Dantas, Pedro Bala, João Grande, Volta Seca, Pirulito, Padre José Pedro, o Cônego, o superior dos Capuchinhos, Boa-Vida, Sem-Pernas.

**O que acontece:**
- **p. 228:** os meninos ainda procuram Dora no trapiche; Pedro a procura no céu.
- ★ **p. 228–231: o Professor segue o cartão.** Ele procura o Dr. Dantas, o homem da piteira, que é **poeta**, e vai para o **Rio de Janeiro** estudar com um pintor: "Um dia vou mostrar como é a vida da gente". Recebe viva do grupo e um punhal de Volta Seca. Depois larga o pintor acadêmico para pintar por conta própria quadros que "espantam o país".
- **p. 231–232:** **Pirulito** deixa de roubar, vende jornal, engraxa sapatos e ouve "o chamado de Deus".
- ★ **p. 232–234:** o Cônego dá ao padre José Pedro uma **paróquia no alto sertão, entre cangaceiros**, recomendando que desista das "inovações soviéticas". O padre fica feliz ("os cangaceiros são como crianças grandes"). O superior dos Capuchinhos aceita **Pirulito** como irmão leigo: ele vira **Irmão Francisco da Sagrada Família**, e talvez um dia se ordene. Despedida na estação; o padre chora no trem.
- **p. 234:** **Boa-Vida** vai virando malandro, com violão e samba.
- ★ **p. 234–235:** Pedro e Sem-Pernas veem Pirulito ensinando catecismo. Sem-Pernas diz: "A bondade não basta... Só o ódio". Pedro responde: **"Nem o ódio, nem a bondade. Só a luta."**

**Análise:** a Igreja **"premia" o padre afastando-o**. A vocação de Pirulito é verdadeira, mas é uma **salvação individual**: para Pedro, "não dá de comer". A frase de Pedro é a síntese ideológica do livro.

### Canção de amor da vitalina (p. 236–240)
**Quem aparece:** Sem-Pernas, Joana (a vitalina), a criada velha, Pedro Bala, Gato.

- ★ Sem-Pernas se infiltra na casa da solteirona rica **Joana**, de 45 anos, que o usa sexualmente "só pela metade" (não vai até o fim). Isso aumenta o **ódio e o desejo frustrado** dele. Ele leva a chave, o grupo rouba a casa e ela tem um ataque.
- **Análise:** mais uma vez o carinho que Sem-Pernas recebe é falso ou incompleto; ele sai pior do que entrou.

### Na rabada de um trem (p. 241–248)
**Quem aparece:** Gato, Dalva, Pedro Bala, João Grande, Volta Seca, Lampião, Zé Baiano, dois soldados.

**O que acontece:**
- **p. 241–242:** a alta do cacau em **Ilhéus**, com cabarés, coronéis e mulheres vindas de vários estados.
- ★ **p. 242–244: o Gato cafetão.** O Gato vive do dinheiro de Dalva desde os 14 anos. Vai com ela para Ilhéus, veste roupa de casimira feita sob medida e vira "o mais jovem dos vigaristas da Bahia". Aqui o narrador faz a **grande reflexão sobre os "meninos-homens"** (ver página 8). Pedro, vendo os amigos partirem, ainda não sabe qual será o próprio caminho.
- ★ **p. 244–248: Volta Seca vai atrás de Lampião.** Preso e espancado pela polícia, decide "matar soldados de polícia". Conta-se a história dele: a mãe era comadre de Lampião; quando Lampião se afastou, **os coronéis tomaram as terras dela**, ela foi à cidade pedir justiça e **morreu no caminho**. Ele foge escondido num trem de carga, **encontra o bando** quando Lampião assalta o trem, pede um fuzil, **fuzila dois soldados** e termina de matar um com punhal. Faz as duas primeiras marcas no fuzil.

**Análise:** a rua formou o Gato **jogador, vigarista e gigolô**. Ele é a **malandragem que explora** (golpe e mulher), o "sucesso" individual e desonesto. Mais tarde ele larga Dalva e arranja uma "moreninha"; Pedro pensa que, se ele tivesse ficado mais tempo e conhecido Alberto, talvez não fosse ladrão. Volta Seca é a **revolta armada e sem organização**, que o livro admira (Lampião como "novo Zumbi") mas não aponta como solução.

### ★ Como um trapezista de circo (p. 249–250)
**Quem aparece:** Sem-Pernas, Pedro Bala, João Grande, Barandão, guardas, o cachorro.

- Num assalto na Rua Rui Barbosa, Sem-Pernas fica encurralado. Lembra da surra na cadeia e do homem de colete rindo e **não aceita ser pego de novo**. Sobe no muro do elevador, **ri com toda a força do seu ódio, cospe na cara de um guarda** e se joga de costas "como se fosse um trapezista de circo". O cachorro dele late entre as grades.
- **Por quê:** nunca teve amor por quem ele era; o único carinho (Dona Ester) ele teve de abandonar; a vitalina aumentou o ódio; "amava unicamente o seu ódio".
- **Análise:** o suicídio é, ao mesmo tempo, **vingança e liberdade**. O cachorro é a única criatura que ele amou.

### Notícias de jornal (p. 251–254)
**Quem aparece:** Professor (o pintor João José), Gato, Boa-Vida, Volta Seca, Lampião, Machadão.

- ★ **Professor:** sua exposição no Rio faz sucesso. Um crítico nota que os bons sentimentos aparecem sempre numa **menina magra de cabelos loiros e faces febris** (Dora) e os maus num **homem de sobretudo negro** (o homem que o chutou).
- **Gato:** preso como vigarista; vendeu o leito do rio Cachoeira como terra para cacau e foi mandado de Ilhéus para Belmonte e de volta.
- **Boa-Vida:** abriu a cabeça de um homem com uma garrafa numa festa.
- ★ **Volta Seca:** vira cangaceiro temido e cruel (35 marcas, depois 60; mata um sargento aos pedaços). Lampião mata o cangaceiro **Machadão**, que se horrorizou com a crueldade dele. Volta Seca é **preso** dormindo pela volante e **condenado a 30 anos** por 15 mortes provadas. O laudo médico diz que ele é "normal": **"fora o ambiente"**. No júri ele não chora.
- **Atenção:** no livro **Volta Seca não morre**, é preso e condenado. Quem morre é Machadão e o cangaceiro da cabeça cortada.

### ★ Companheiros (p. 255–264)
**Quem aparece:** Pedro Bala, João Grande, Barandão, João de Adão, Alberto, os fura-greves e o americano que os chefia.

- **p. 255–256:** há uma **greve dos condutores de bonde**, e os estivadores de João de Adão aderem em solidariedade. Pedro acha a greve "a mais bela das aventuras".
- **p. 256–257:** Pedro pensa em Dora como estrela e em Rosa Palmeirão e Maria Cabaçu, mulheres valentes que viraram santas.
- ★ **p. 258–262:** João de Adão apresenta **Alberto**, estudante comunista: "a greve é a festa dos pobres". A palavra **"companheiro"** encanta Pedro. O plano: impedir os **fura-greves** para que os operários não precisem brigar e a polícia não tenha pretexto. Pedro lembra que Professor era "um companheiro bom".
- ★ **p. 263–264:** os meninos defendem os três depósitos de bondes; Pedro derruba o americano; "a greve não é furada".

**Análise:** é a **consciência de classe na prática**: a energia do grupo é canalizada para a luta coletiva. Pedro realiza o que o pai fazia ("tem sangue de grevista").

### ★ Os atabaques ressoam como clarins de guerra (p. 265–269)
**Quem aparece:** Pedro Bala, Alberto, Gato, João Grande, Barandão, os Capitães.

- **p. 265:** o grupo vira **brigada de choque** em comícios e greves. O **Gato** reaparece rico, larga Dalva (que se amigou com um coronel), vende o anelão falso a um coronel e vai para Aracaju.
- ★ **p. 266–267:** **"A revolução chama Pedro Bala"**, como Deus chamava Pirulito. **João Grande vira marinheiro** num cargueiro do Lloyd. Pedro se despede com "Adeus, **companheiro**": não é mais um adeus, é uma saudação.
- ★ **p. 267–269:** Pedro entra na organização e é mandado organizar os **Índios Maloqueiros de Aracaju**. **Barandão (15 anos) vira o novo chefe.** Os meninos se despedem de **punhos fechados** gritando "Bala! Bala!". O livro termina com a mesma imagem do começo: "sob a lua, num velho trapiche" (**estrutura circular**).

### ★ Uma Pátria e uma família (p. 270)
- Anos depois, jornais operários clandestinos falam do **"camarada Pedro Bala"**, perseguido pela polícia de 5 estados como organizador de greves, preso numa colônia, que foge. Frase final: **"a revolução é uma pátria e uma família"**, justamente o que ele nunca teve.
- As datas no fim do livro: Estância (SE), março de 1937; *Rakuyo Maru*, junho de 1937.

### Pratique: página 6

1. Qual é o destino do Professor?
    - A) Vira padre
    - B) Vira pintor no Rio de Janeiro
    - C) Morre no lazareto
    - D) Vira estivador
    - *Resposta: B. Com ajuda do Dr. Dantas, o homem da piteira; seus quadros mostram a menina loira (Dora) e o homem de sobretudo.*
2. O que acontece com Volta Seca no fim?
    - A) Morre num tiroteio
    - B) Vira cangaceiro, é preso e condenado a 30 anos
    - C) Volta para o trapiche
    - D) Vira policial
    - *Resposta: B. Ele não morre: é preso dormindo e condenado por 15 mortes provadas.*
3. Como Sem-Pernas morre?
    - A) Na cafua
    - B) Se joga do elevador para não ser preso
    - C) De varíola
    - D) Numa briga com Ezequiel
    - *Resposta: B. Ele cospe na cara de um guarda e se joga "como um trapezista de circo".*
4. O que os Capitães fazem na greve dos bondes?
    - A) Furam a greve
    - B) Impedem os fura-greves nos três depósitos
    - C) Roubam os bondes
    - D) Chamam a polícia
    - *Resposta: B. Assim os operários não precisam brigar e a polícia não tem pretexto.*
5. Quem vira o novo chefe dos Capitães?
    - A) João Grande
    - B) Barandão
    - C) Zé Fuinha
    - D) Gato
    - *Resposta: B. Barandão, com 15 anos, quando Pedro vai para Aracaju.*
6. Quem apresenta Alberto a Pedro Bala?
    - A) Padre José Pedro
    - B) João de Adão
    - C) Querido-de-Deus
    - D) Don'Aninha
    - *Resposta: B. João de Adão, o estivador grevista.*
7. Explique a frase "Nem o ódio, nem a bondade. Só a luta."
    - *Resposta esperada: O ódio (Sem-Pernas) leva à morte; a bondade individual (Pirulito, o padre) não muda a vida dos pobres. Só a luta coletiva organizada muda o destino.*
8. Qual é o destino de cada um: Pirulito, Gato, Boa-Vida e João Grande?
    - *Resposta esperada: Pirulito: frade capuchinho. Gato: vigarista em Ilhéus. Boa-Vida: malandro e sambista. João Grande: marinheiro.*
9. O que significa o final "a revolução é uma pátria e uma família"?
    - *Resposta esperada: Pedro Bala, que nunca teve família nem proteção do Estado, encontra na luta política a comunidade que lhe faltou.*


---

## 7. Personagens e a função de cada um

### Os Capitães da Areia

**Personagens planos, revelados por ações.** Quase todos são **planos/tipos**: cada um é definido por **um traço dominante**, uma "vocação", e o leitor descobre quem ele é **pelo que faz**, não por análise psicológica longa. Cada traço vira **destino**. É um recurso do romance engajado: cada menino **representa um caminho possível** para a criança abandonada. A exceção é **Pedro Bala**, o único que **evolui** de verdade (de chefe de ladrões a militante), e por isso fica mais perto de um personagem **redondo/esférico**. Sem-Pernas tem mais conflito interior que os outros, mas não muda.

| Personagem | Traço / como aparece | Ações que o revelam | Destino | Função / o que representa |
|---|---|---|---|---|
| **Pedro Bala** | Loiro, cicatriz no rosto, líder, ágil, capoeirista. Filho do grevista Raimundo "o Loiro" | Toma a chefia de Raimundo; engana a polícia pelo Ogum; aguenta a tortura sem entregar o trapiche; foge nu do reformatório; o estupro; o amor por Dora; defende Almiro do lazareto | Militante comunista e líder grevista, perseguido e preso, foge | **A consciência de classe.** Mostra que o caminho é **a luta coletiva** |
| **Professor** (João José) | Magro, míope, leitor, conta histórias e desenha. O "cérebro" dos planos | Rouba livros e não vende; desenha a giz; vinga-se do homem do sobretudo; ama Dora em silêncio | **Pintor social** famoso no Rio | **A arte como denúncia.** Os quadros contam a vida dos meninos (Dora = bem, homem de sobretudo = mal) |
| **João Grande** | Negro, 13 anos, o mais alto e forte, "burro" mas **o mais bondoso** ("Tu é melhor que a gente") | Protege os menores; consola a mulher das cartas; **defende Dora** contra todos, até contra Pedro; tem medo da bexiga | **Marinheiro** | **A bondade e a força protetora.** A consciência moral do grupo |
| **Sem-Pernas** | Coxo, sarcástico, cheio de ódio. Espião que finge ser órfão coitado | Zomba de todos; quer expulsar Almiro; foge da casa de Dona Ester chorando; cuida de um cachorro; a vitalina | **Suicídio** (se joga do Elevador Lacerda) | **O ódio e a dor sem saída.** Mostra a infância destruída pela violência e a falta de carinho |
| **Pirulito** (Antônio) | Magro, alto, místico, reza a Nossa Senhora das Sete Dores. Já foi dos mais malvados | Rouba o Menino Deus; jejua; larga o furto; divide o medo do inferno com Dora | **Frade capuchinho** (Irmão Francisco da Sagrada Família) | **A religião como fuga individual.** Para Pedro, "não dá de comer" |
| **Volta Seca** | Mulato sertanejo, sombrio, afilhado de Lampião, imita bichos | Anda armado de revólver; defende Almiro ("é um do grupo"); vê a mãe em Dora | **Cangaceiro**, preso e condenado a 30 anos | **A revolta armada e a vingança.** Liga o livro ao sertão e ao cangaço |
| **Gato** | Bonito, elegante, malandro, baralho marcado, amante de Dalva | Rouba o anelão; vence no jogo e devolve a quem é amigo; sente a mãe em Dora | **Vigarista/golpista** em Ilhéus | **A malandragem que explora** (vive de mulher e de golpe). O "sucesso" individual e desonesto |
| **Boa-Vida** | Mulato, preguiçoso, violão, ama a cidade | Apresenta o padre ao grupo; **vai sozinho para o lazareto** para não contaminar ninguém | **Malandro** e sambista | **A malandragem baiana.** Mostra que mesmo o "parasita" tem "uma estrela no lugar do coração" |
| **Dora** | Loira, 13–14 anos, órfã da varíola | Cuida de todos, rouba junto, briga com o grupo de Ezequiel, se entrega a Pedro | **Morre de febre** e vira estrela | **O afeto que faltava**: mãe, irmã, noiva e esposa. Humaniza o grupo |
| **Barandão** | Negrinho, corajoso, medo da bexiga | Relação com Almiro; chefia um grupo na greve | **Novo chefe** dos Capitães | **A continuidade** e a nova geração, já politizada |

**Outros do grupo:** **Almiro** (pega alastrim e morre no lazareto), **Zé Fuinha** (irmão de Dora), **o Gringo** (filho de árabes, alvo de Sem-Pernas), **Raimundo, o Caboclo** (ex-chefe).

### Os adultos

| Personagem | Quem é | Função |
|---|---|---|
| **Padre José Pedro** | Ex-operário de fábrica de tecidos, mau aluno no seminário, humilde, batina suja e remendada. Trata os meninos "como a homens" | **A caridade cristã verdadeira**, que esbarra na Igreja oficial. Pega dinheiro das velas para o carrossel, esconde a varíola de Almiro, aceita jogar Dora no mar. Chamado de "comunista" pelo Cônego, duvida e às vezes acha que João de Adão tem razão. Ganha uma paróquia no sertão. Mostra que **a bondade individual não basta** |
| **Querido-de-Deus** | Pescador, o maior capoeirista da Bahia, ogã, devoto de Xangô | **O adulto-herói popular.** Ensina capoeira (que salva Pedro na prisão), traz "serviços", leva o corpo de Dora para o mar e **resgata Pedro Bala** |
| **João de Adão** | Estivador negro, antigo grevista, comunista | **O mentor político.** Revela a história do pai, fala de direitos e revolução, apresenta Alberto |
| **Alberto** | Estudante da Faculdade, comunista | **A organização (o Partido).** Transforma o grupo em brigada de choque e leva Pedro para a militância |
| **Don'Aninha** | Mãe-de-santo do terreiro do Opô Afonjá | **A religião afro como resistência e cuidado.** Cura doentes, pede Ogum de volta, reza por Dora, envolve o corpo dela para Yemanjá, clama contra os ricos e a polícia |
| **Diretor do Reformatório** | Autoritário, hipócrita | **A violência do Estado.** Cita **Lombroso**, chama Pedro de "criminoso nato", manda para a cafua |
| **Delegado/comissário** (caso Ogum) | Jovem advogado de rubi no dedo, com pretensões literárias | **A autoridade distraída e vaidosa**, enganada pela esperteza do menino |
| **Investigador e soldados** | Torturam Pedro Bala para ele entregar o trapiche | Repressão |
| **Dalva** | Prostituta de ~35 anos, amante do Gato | Mostra o Gato "homem" antes do tempo. Vai para Ilhéus e depois se amiga com um coronel |
| **Cônego** | Frio, "puro", distante | **A Igreja institucional aliada dos ricos** |
| **Viúva Margarida Santos** | Rica, "protetora da religião" | **A hipocrisia burguesa** |
| **Dona Ester e Raul** | Casal rico que perdeu o filho Augusto | **Exceção ao maniqueísmo**: ricos bons |
| **Nhozinho França** | Dono do carrossel, bêbado | Dá aos meninos a única infância que eles têm |
| **Dr. Dantas** | O "homem da piteira", poeta | Dá ao Professor a chance de estudar |
| **Joana (a vitalina)** | Solteirona rica | Abusa de Sem-Pernas |
| **Maria Ricardina** | Costureira | A voz do povo nas cartas |
| **Gonzales do 14** | Dono de casa de penhor | Receptador que explora os meninos |
| **Ezequiel** | Chefe de outra gangue | O **contraponto** aos Capitães (ver página 8) |
| **Lampião** | Cangaceiro real | **Referência** (ver página 8) |

---

### Pratique: página 7

1. Por que se diz que a maioria dos personagens é "plana"?
    - A) Porque aparecem pouco
    - B) Porque cada um tem um traço dominante, revelado por ações, que vira destino
    - C) Porque não falam
    - D) Porque são adultos
    - *Resposta: B. Cada menino representa um caminho possível; Pedro Bala é o que evolui.*
2. Qual personagem representa a religião como fuga individual?
    - A) Volta Seca
    - B) Pirulito
    - C) Gato
    - D) Boa-Vida
    - *Resposta: B. Pirulito vira frade.*
3. Qual adulto ensina capoeira aos meninos?
    - A) João de Adão
    - B) Querido-de-Deus
    - C) Nhozinho França
    - D) Alberto
    - *Resposta: B. O Querido-de-Deus, pescador e capoeirista.*
4. Qual casal rico é uma exceção ao maniqueísmo?
    - A) Dona Laura e o filho
    - B) Dona Ester e Raul
    - C) A viúva Santos e o Cônego
    - D) O comendador e a esposa
    - *Resposta: B. Eles acolhem Sem-Pernas com carinho verdadeiro.*
5. Qual é a função de João Grande no grupo?
    - *Resposta esperada: É a bondade e a força protetora, a consciência moral: protege os menores e defende Dora até contra Pedro.*
6. Diferencie o padre José Pedro do Cônego.
    - *Resposta esperada: O padre é pobre, ex-operário, ajuda os meninos e é acusado de comunista; o Cônego representa a Igreja oficial, fria e aliada dos ricos, que o afasta para o sertão.*


---

## 8. Temas para análise

### Socialismo e comunismo dentro do livro
- **Tese do livro:** a miséria das crianças é **culpa da estrutura social** (ricos × pobres), e a solução é **coletiva e revolucionária**.
- **Onde aparece:**
  - João de Adão ("a culpa era da sociedade mal organizada, dos ricos", "só a revolução acertaria tudo");
  - Alberto e a "organização";
  - o Cônego chamando o padre de comunista;
  - o vocabulário final: "companheiros", "camarada", punhos fechados, "brigada de choque", "a revolução chama Pedro Bala", "a revolução é uma pátria e uma família";
  - a comparação com os meninos antifascistas da Itália.
- **As três soluções testadas:**
  - **bondade/caridade** (padre José Pedro, Pirulito): "não dá de comer";
  - **ódio individual** (Sem-Pernas, Volta Seca): leva à morte ou à prisão;
  - **luta organizada** (Pedro Bala): a que o livro aprova. **"Nem o ódio, nem a bondade. Só a luta."**
- Por isso o livro é considerado **literatura engajada/panfletária**, e foi queimado.

### Consciência de classe: Pedro Bala de líder de bando a líder grevista
É o **eixo do romance de formação** (tem traços de *Bildungsroman*). As etapas:

1. **Instinto:** chefe de ladrões, ágil e esperto.
2. **Revelação** (Docas): o pai morreu na greve pelos "direitos" dos doqueiros.
3. **Culpa e reconhecimento** (estupro): "uma criança também".
4. **Religião dos pobres** (Omolu, Ogum): os pobres não têm nem seu deus em paz.
5. **Destino** (Porta do Mar): "um dia a gente muda".
6. **Tortura e cafua**: descobre que "**a liberdade é o bem maior do mundo**".
7. **Perda de Dora**, que vira a estrela-guia.
8. **Síntese:** "Nem o ódio, nem a bondade. Só a luta."
9. **Prática:** a greve dos bondes; "companheiros".
10. **Militância:** passa a mudar o destino de **outras** crianças.

Ele passa do **"eu/nós do grupo"** para o **"nós, os pobres"**: essa é a consciência de classe.

### Os problemas sociais dentro do livro
- **Abandono infantil** e trabalho infantil.
- **Violência policial e tortura.**
- **Reformatório e orfanato** que embrutecem.
- **Doença e saúde pública desigual** (vacina × lazareto).
- **Fome**, falta de **escola** e de moradia.
- **Racismo e intolerância religiosa** (apreensão de Ogum).
- **Exploração sexual e prostituição.**
- **Exploração do trabalho** (estivadores, condutores de bonde, lavradores do sertão).
- **Latifúndio** (terras da mãe de Volta Seca, coronéis do cacau).
- **Imprensa parcial**, **Igreja elitista** e **preconceito de classe** (viúva Santos, Dona Laura).

### Órfãos de família e do Estado
- São **órfãos duas vezes**:
  - **de família**: pais mortos (Pedro, Dora, João Grande) ou violentos (Sem-Pernas, criado por um padeiro que o surrava);
  - **do Estado**, que só aparece para **punir** (polícia, reformatório, orfanato, lazareto) e nunca para **proteger**.
- Quem cuida deles é **gente que está fora do poder**: um padre marginalizado, uma mãe-de-santo, um capoeirista, um estivador.
- O grupo vira **família substituta** e tem sua "lei".
- No fim, Pedro encontra a família que faltava na revolução: "**uma pátria e uma família**".

### Meninos HOMENS e as coisas que não são de crianças
- O narrador diz que eles **"nunca tinham parecido crianças"** e eram **"iguais a homens"**: amavam, roubavam, apanhavam e falavam como homens. Só mudava o tamanho. **"O que faz a criança é o ambiente de casa, pai, mãe, nenhuma responsabilidade."**
- **Coisas de adulto que eles vivem:** sexo precoce e violento, prostituição (Gato e Dalva), cachaça e cigarro, armas (punhal, navalha, revólver), roubo, tortura, cadeia, morte, suicídio, estupro, cangaço.
- O padre diz ao Cônego: "São meninos iguais a homens". Dora diz o contrário: "É tudo uns menino".
- **O contraste** que aparece nos momentos de infância: o **carrossel**, as histórias do Professor, a gargalhada, o bebê alimentado, Dora como mãe. **O livro é justamente sobre essa infância roubada.**

### Bandidos com causa / bandidos heróis
- São ladrões, mas o narrador os apresenta como **"donos da cidade", "poetas"**, e a gargalhada deles é "**um hino do povo da Bahia**".
- **Têm ética:** lealdade, não roubar colega, proteger os pequenos, pagar dívida de gratidão (Ogum, o padre).
- **Roubam principalmente dos ricos** (Corredor da Vitória, Graça), numa espécie de "Robin Hood" baiano.
- **Lampião** é visto por Volta Seca como "novo **Zumbi dos Palmares**", "braço armado dos pobres". **Cuidado:** o próprio livro mostra a crueldade do cangaço.
- **Heróis populares citados:** Zumbi, Lucas da Feira, Besouro, Rosa Palmeirão, Maria Cabaçu, todos valentes que viram estrela ou santo.
- **Causa:** o crime é **resposta à injustiça**, e no fim essa energia é **canalizada para a luta política** (bandidos → militantes).

### Lampião como referência
- **Ligações com o enredo:**
  - é o **padrinho** de Volta Seca;
  - andou no carrossel de Nhozinho (os cangaceiros "foram como crianças", e isso salvou a vila);
  - aparece nas notícias de jornal (o cangaceiro de cabeça cortada, depois Volta Seca no bando);
  - Pedro Bala, na cafua, o ama "como a um seu herói, a um seu vingador".
- **Função:**
  - estende a crítica social **ao sertão** (coronéis, latifúndio);
  - mostra que o sertanejo pobre também é "abandonado";
  - representa **a revolta armada e individual**, que o livro admira mas **não aponta como solução**.

### A Dor e as faces dela dentro dos Capitães
Cada menino tem **uma dor** e **uma fuga** para ela. Sem-Pernas percebe: "Todos procuravam um carinho".

| Personagem | A dor | A "fuga" |
|---|---|---|
| Sem-Pernas | Deficiência, a surra na cadeia, nenhum carinho | Ódio, zombaria, e por fim a morte |
| Professor | Humilhação (o homem do sobretudo), talento sem escola | Livros e arte |
| Pirulito | Culpa, medo do inferno | Religião |
| Volta Seca | Perda da mãe e da terra, surra da polícia | Vingança e cangaço |
| Gato | Perda da mãe | Mulheres, elegância, dinheiro |
| Boa-Vida | Lazareto, a morte de perto | Malandragem, samba |
| João Grande | Pai morto atropelado, medo da bexiga | Bondade, proteger os outros |
| Barandão e Almiro | Solidão | Carinho entre eles |
| Dora | Orfandade, rejeição, orfanato, febre | Cuidar dos outros, amor |
| Pedro Bala | Pai assassinado, tortura, a morte de Dora | Liderança, e por fim a luta |

Também é dor **coletiva**: noites de chuva no trapiche, sem "doces palavras de mãe", fome, frio, morte sem remédio.

### Maniqueísmo
- **O que é:** divisão rígida entre **bem e mal**.
- **No livro:** em geral, **pobres = bons** (João de Adão, Don'Aninha, Querido-de-Deus, José Pedro, a garçonete, os estivadores) e **ricos e autoridades = maus** (diretor, investigador, Cônego, viúva Santos, Dona Laura, o homem do sobretudo, o comendador, a imprensa, os fura-greves). Os quadros do Professor repetem essa divisão (a menina loira × o homem de sobretudo).
- **É uma crítica comum ao livro:** ele fica **panfletário e simplificado** por causa do engajamento político.
- **Mas há nuances,** que valem ponto na prova:
  - **ricos bons**: Dona Ester, Raul, Dr. Dantas, Nhozinho;
  - **pobres cruéis**: o estupro de Pedro Bala, o quase estupro coletivo de Dora, a crueldade de Volta Seca, Sem-Pernas chutando Almiro, a gangue de Ezequiel, os delatores do reformatório;
  - **um padre bom dentro de uma Igreja má.**
- **Conclusão:** o maniqueísmo é mais de **classe** (o sistema) do que de **indivíduo**.

### A visão do autor sobre o livro
- Jorge Amado **toma partido** das crianças e dos pobres. O narrador os defende, os poetiza e culpa **a sociedade**, não os meninos: "A culpa era da vida" (padre), "Fora o ambiente" (laudo), "a culpa não é da gente, a gente não tem ninguém" (Dora).
- **Contra** o determinismo biológico (Lombroso, "criminoso nato"), **a favor** do determinismo **social**.
- **Mistura denúncia e lirismo:** a Bahia é "a mais misteriosa e bela das cidades", cheia de mar, lua, candomblé, capoeira e samba. **Valoriza a cultura negra e popular.**
- Acredita que **o destino pode mudar**, e a mudança só vem **coletivamente**, pela revolução. O final é **otimista e militante**: "o destino deles mudou".

### O trapiche, as docas e as ruas (espaços)
- **Trapiche:** **lar improvisado**, ruína do passado colonial e escravista (antes o mar batia ali; agora é areia). É **símbolo do abandono** (ratos, chuva pelo telhado), mas também de **liberdade e comunidade**. O livro **começa e termina** "sob a lua, num velho trapiche abandonado" (**estrutura circular**).
- **Docas:** **o espaço do trabalho e da luta operária**, onde Pedro descobre o pai e sua classe. O sangue do pai "sob o asfalto".
- **Ruas e ladeiras:** **a liberdade** ("não existe nada melhor no mundo que andar assim, ao azar, nas ruas da Bahia"), o lugar do roubo e da aventura.
- **Cidade alta × cidade baixa:** a **geografia da desigualdade** (Vitória, Graça, Barra dos ricos × cais, morro, Cidade de Palha dos pobres).
- **Instituições fechadas** (reformatório, orfanato, lazareto, cafua): escuridão e morte. Opõem-se ao **sol e ao mar** (liberdade).

### As meninas do areal e o que os Capitães da Areia fizeram

**O que o livro conta:**

1. **A violência sexual como costume do grupo.** Desde o primeiro capítulo, o narrador diz que os meninos não pagavam mulher porque "tinham as negrinhas" para "derrubar no areal". O areal das docas é descrito como a "cama" de todos os malandros e de todos os Capitães da Areia. As meninas eram negras, pobres e às vezes tão novas quanto eles, e eram tomadas à força. Os meninos falam disso contando vantagem, como se fosse normal.
2. **Pedro Bala violenta uma menina (capítulo "Docas").** Ele sai abalado de duas revelações: o pai morreu numa greve e, no candomblé, Omolu anunciou a vingança dos pobres. Persegue uma menina negra de uns 15 anos que voltava da casa da avó, derruba-a na areia e a força. Ela implora e diz que é virgem, e ele abusa dela mesmo assim. Depois ela o amaldiçoa ("Peste, fome e guerra te acompanha") e cospe no chão. Ele fica com vergonha e tristeza e escuta dentro de si: **"Uma criança também"**.
3. **Sem-Pernas só conseguia as meninas à força, com ajuda de outros.** O livro diz que nenhuma olhava para ele, o que dá a entender violência em grupo.
4. **Nem todas as relações eram forçadas.** O livro também fala de meninas que "ofereciam o amor na areia". Pirulito, por causa da religião, fugia delas.
5. **Dora quase sofre o mesmo.** Quando ela chega ao trapiche, a maioria quer violentá-la em grupo, e Pedro Bala, no começo, concorda. João Grande e Professor a salvam com o argumento de que ela "é uma menina". A partir dali o grupo a trata como mãe e irmã.
6. **Pedro Bala muda de visão.** Na cafua do reformatório, ele pensa que sempre achou que amor era só derrubar uma menina no areal. Com Dora descobre outro tipo de amor, com respeito e carinho. O sexo com Dora é o oposto do estupro: é ela quem quer.

**Como analisar na prova:**

- **Os heróis não são idealizados.** Vítimas do Estado, da polícia e da fome, os meninos também são agressores: repetem a violência contra quem é mais fraco.
- **As meninas são as mais vulneráveis.** Pobres, negras, mulheres e crianças, sem ninguém que as proteja: no areal, à noite, não havia a quem pedir socorro.
- **Meninos-homens.** O sexo violento é uma das coisas de adulto que eles vivem cedo demais.
- **Quebra do maniqueísmo.** O livro não é só "pobre bom × rico mau": os pobres também cometem violência.
- **Início da consciência de Pedro Bala.** Quando ele reconhece que a menina é "uma criança também", vê nela alguém igual a ele. É um dos primeiros passos do despertar dele.
- **Crítica ao próprio livro.** O narrador às vezes descreve o corpo das meninas negras de forma sexualizada, como se o desejo dos meninos fosse natural. Hoje isso é lido como objetificação e racismo. Mencionar essa crítica mostra leitura madura.
- **Progressão das cenas:** estupro da menina (violência), tentativa contra Dora que é impedida (respeito), noite de amor com Dora (amor consentido).

---

### Pratique: página 8

1. Que tipo de determinismo o livro defende?
    - A) Biológico (Lombroso)
    - B) Social: o ambiente explica o crime
    - C) Religioso: tudo é destino divino
    - D) Nenhum
    - *Resposta: B. O laudo sobre Volta Seca diz: "fora o ambiente".*
2. Os meninos são "órfãos duas vezes" porque…
    - A) perderam pai e mãe
    - B) não têm família e o Estado só aparece para punir
    - C) foram abandonados duas vezes pela mesma mãe
    - D) saíram do orfanato e do reformatório
    - *Resposta: B. Sem família e sem proteção: polícia, reformatório, orfanato e lazareto só punem.*
3. Qual cena mostra melhor que eles ainda são crianças?
    - A) A greve
    - B) O carrossel
    - C) A cafua
    - D) O assalto ao comendador
    - *Resposta: B. No carrossel eles "foram iguais a todas as crianças".*
4. Dê um exemplo de maniqueísmo e um exemplo que o quebra.
    - *Resposta esperada: Maniqueísmo: ricos, polícia e Igreja oficial maus; pobres bons. Quebra: Dona Ester e Raul são ricos bons; Pedro Bala comete um estupro; Volta Seca é cruel.*
5. Explique a ideia de "meninos-homens".
    - *Resposta esperada: Eles vivem coisas de adulto (sexo, violência, roubo, prisão, prostituição) e nunca tiveram infância, porque "o que faz a criança é o ambiente de casa". Só o tamanho era de criança.*
6. Por que os Capitães podem ser vistos como "bandidos com causa"?
    - *Resposta esperada: Roubam principalmente dos ricos, têm uma ética própria (lealdade, não roubar colega, proteger os pequenos) e no fim canalizam essa energia para a luta política.*
7. Como a violência contra as meninas do areal aparece e como deve ser analisada?
    - *Resposta esperada: Era costume do grupo "derrubar" meninas negras e pobres no areal; Pedro violenta uma menina de 15 anos. Mostra que as vítimas também agridem, as meninas são as mais vulneráveis, e há crítica à forma sexualizada como o narrador as descreve.*
8. Qual é a visão do autor sobre o problema dos meninos?
    - *Resposta esperada: A culpa é da sociedade, não das crianças; a caridade não basta; a solução é coletiva e revolucionária. Ele denuncia com lirismo e valoriza a cultura negra e popular da Bahia.*


---

## 9. Revisão final

### Uma frase por parte

1. **Cartas:** a sociedade (jornal, polícia, juiz, diretor) acusa os meninos e esconde a verdade que as vozes pobres denunciam.
2. **Parte 1:** apresenta o grupo, sua ética, suas dores e aventuras (carrossel, Ogum, Família, varíola) e o despertar de Pedro Bala (o pai grevista).
3. **Parte 2:** Dora chega e humaniza o grupo como mãe, irmã, noiva e esposa. Vêm a prisão, o reformatório, o orfanato e a morte dela.
4. **Parte 3:** o grupo se dissolve em destinos individuais, e Pedro Bala encontra na luta coletiva (a revolução) a sua "pátria e família".


### Possíveis perguntas de prova (com resposta curta)

- **Por que o livro começa com cartas?** Para imitar a imprensa, mostrar as versões oficiais e sua hipocrisia (o espaço dado a cada voz) e dar tom documental/neorrealista. O resto do livro desmente as cartas.
- **Qual a frase-síntese da ideologia do livro?** "Nem o ódio, nem a bondade. Só a luta."
- **Personagens planos ou redondos?** A maioria é plana, definida por um traço revelado por ações (a vocação vira destino). Pedro Bala é o que evolui.
- **Qual o único momento de infância?** O carrossel.
- **Qual o papel de Dora?** O afeto feminino que faltava (mãe, irmã, noiva e esposa). Humaniza e une o grupo. Sua morte provoca a dissolução.
- **Como o livro vê o Estado?** Ausente para proteger, presente só para punir (reformatório, polícia, lazareto, orfanato).
- **Por que foi queimado?** Tinha conteúdo comunista e de denúncia social e saiu no início do Estado Novo de Vargas (1937).
- **Que determinismo o livro defende?** O social (o ambiente), contra o biológico de Lombroso ("criminoso nato").
- **Os Capitães são só vítimas?** Não. Também cometem violência, sobretudo contra as meninas do areal (o estupro cometido por Pedro Bala e a tentativa contra Dora). O livro mostra que a violência sofrida é repetida contra os mais fracos, e Pedro Bala reconhece a vítima como "uma criança também".
- **Destino de cada um?** Pedro: militante. Professor: pintor. João Grande: marinheiro. Pirulito: frade. Gato: vigarista. Boa-Vida: malandro. Volta Seca: cangaceiro preso. Sem-Pernas: suicídio. Dora: morte. Barandão: novo chefe.

### O destino de cada um (decorar)

| Personagem | Destino | O que representa |
|---|---|---|
| Pedro Bala | Militante comunista, líder grevista, preso e foragido | A luta coletiva (a saída que o livro aprova) |
| Professor | Pintor social famoso no Rio | A arte como denúncia |
| João Grande | Marinheiro | A bondade |
| Pirulito | Frade capuchinho | A religião, salvação individual |
| Gato | Vigarista em Ilhéus | A malandragem que explora |
| Boa-Vida | Malandro e sambista | A malandragem baiana |
| Volta Seca | Cangaceiro, preso e condenado a 30 anos | A revolta armada e individual |
| Sem-Pernas | Suicídio no elevador | O ódio sem saída |
| Dora | Morre de febre e vira estrela | O afeto que faltava |
| Barandão | Novo chefe do grupo | A nova geração, já politizada |
| Padre José Pedro | Paróquia no sertão | A caridade que não basta |

### Pratique: página 9

1. Complete: Pedro Bala termina como…
    - A) frade
    - B) militante comunista e líder grevista
    - C) cangaceiro
    - D) pintor
    - *Resposta: B. Perseguido em 5 estados, preso numa colônia, foge.*
2. Qual destino NÃO está certo?
    - A) Gato: vigarista
    - B) Professor: pintor
    - C) Volta Seca: morto em combate
    - D) Sem-Pernas: suicídio
    - *Resposta: C. Volta Seca é preso e condenado a 30 anos; não morre no livro.*
3. Sem olhar, liste o destino de 8 personagens.
    - *Resposta esperada: Pedro: militante. Professor: pintor. João Grande: marinheiro. Pirulito: frade. Gato: vigarista. Boa-Vida: malandro. Volta Seca: cangaceiro preso. Sem-Pernas: suicídio. Dora: morre e vira estrela. Barandão: novo chefe.*
4. Monte uma resposta dissertativa: como Pedro Bala forma sua consciência de classe?
    - *Resposta esperada: Descobre o pai grevista (Docas); reconhece a vítima no areal; defende os pobres (Ogum); resiste à tortura e aprende que a liberdade é o bem maior (reformatório); perde Dora; conclui "só a luta"; participa da greve e vira militante.*


---

*Observação: os três vídeos do YouTube não puderam ser abertos (o YouTube bloqueou o acesso), então este resumo se baseia só no texto integral do livro. Se o professor destacou algo específico nos vídeos, compare com as seções acima.*
